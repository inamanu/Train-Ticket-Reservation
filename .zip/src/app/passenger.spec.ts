import { Passenger } from './passenger';

describe('Passenger', () => {
  it('should create an instance', () => {
    expect(new Passenger()).toBeTruthy();
  });
});
