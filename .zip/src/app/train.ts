export class Train {
    trainNo!:string;
    trainName!: string;
    source!:string;
    destination!:string;
    ticketprice!: string;
    id!:String;
}
