export class Passenger {
    name! :string;
    age! :string;
    gender! :string;    
  id!: string;
}
