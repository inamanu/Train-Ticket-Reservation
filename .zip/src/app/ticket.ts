export class Ticket {
    counter!:String;
    trainName!:String;
    source!:String;
    destination!:String;
    name!:String;
    age!:String;
    gender!:String;
    travelDate!:String;
    pnr!:String;
    id!:String;
    ticketprice!:String;
}
